﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba11
{
    public class Одномерный_массив
    {
        public int[] array;
        public int size;
        private int index = 0;

        public Одномерный_массив()
        {
            array = new int[0];
            size = 0;
        }
        public Одномерный_массив(int size1)
        {
            array = new int[size1];
            size = size1;
        }
        public void add(int value)
        {

            array[index] = value;
            index++;

        }
        public void sum(Одномерный_массив _arr)
        {

            for (int i = 0; i < size; i++)
            {
                array[i] += _arr.array[i];
            }

        }
        public void sub(Одномерный_массив _arr)
        {

            for (int i = 0; i < size; i++)
            {
                array[i] -= _arr.array[i];
            }

        }
        bool ch; //chetniy
        public bool chet()
        {

            for (int i = 0; i < size; i++)
            {
                if ((array[i] % 2) == 0) { ch = true; }

                else { ch = false; break; }
            }
            return ch;
        }
        bool nch; //nechetniy
        public bool nchet()
        {

            for (int i = 0; i < size; i++)
            {
                if ((array[i] % 2) != 0) { nch = true; }

                else { nch = false; break; }
            }
            return nch;
        }
        public bool chornch()
        {
            if (chet() || nchet()) { return true; }
            else { return false; }
        }
        public int sumel()
        {
            int s = 0;
            for (int i = 0; i < size; i++)
            {
                s += array[i];
            }
            return s;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string[] months = { "June", "July", "August", "September", "October", "November", "December", "January", "February", "March", "April", "May" };
            Console.WriteLine("Request 1:");
            Console.Write("Length of string = ");
            int lenght = int.Parse(Console.ReadLine());
            var request1 = from month in months
                           where month.Length == lenght
                           select month;
            foreach (Object month in request1)
            {
                Console.WriteLine(month);
            }
            Console.WriteLine("Request 2:");
            var request2 = from month in months
                           where (month.Length > 4 && month.Contains('u'))
                           select month;
            int CountOfMonths = 0;
            foreach (Object month in request2)
                CountOfMonths++;
            Console.WriteLine($"Count of Months = {CountOfMonths}");
            Console.WriteLine("Request 3:");
            var request3 = from month in months
                           orderby month
                           select month;
            foreach (Object month in request3)
            {
                Console.WriteLine(month);
            }
            Console.WriteLine("Request 4:");
            var request4 = from month in months
                           where (month == "June" || month == "July" || month == "August" || month == "December" || month == "January" || month == "February")
                           select month;
            foreach (Object month in request4)
            {
                Console.WriteLine(month);
            }
            Одномерный_массив FirstArray = new Одномерный_массив(3);
            FirstArray.add(2);
            FirstArray.add(4);
            FirstArray.add(10);
            Одномерный_массив SecondArray = new Одномерный_массив(3);
            SecondArray.add(6);
            SecondArray.add(5);
            SecondArray.add(1);
            List<Одномерный_массив> ListArrays = new List<Одномерный_массив>();
            ListArrays.Add(FirstArray);
            ListArrays.Add(SecondArray);
            Console.WriteLine("FirstArray:");
            for (int i = 0; i < FirstArray.size; i++)
            {
                Console.WriteLine(ListArrays[0].array[i]);
            }
            Console.WriteLine("SecondArray:");
            for (int i = 0; i < SecondArray.size; i++)
            {
                Console.WriteLine(ListArrays[1].array[i]);
            }
            Console.Write("Request 5: ");
            Console.WriteLine("arrays with only even elements:");
            var request5 = from array in ListArrays
                           where ((array.array[0]) % 2 == 0 && ((array.array[1]) % 2 == 0 && ((array.array[2]) % 2 == 0))) //t chet el
                           select array;
            foreach (object array in request5)
            {
                if (array.Equals(FirstArray))
                {
                    Console.WriteLine("First array:");
                    for (int i = 0; i < FirstArray.size; i++)
                    {
                        Console.WriteLine(ListArrays[0].array[i]);
                    }
                }
                if (array.Equals(SecondArray))
                {
                    Console.WriteLine("Second array:");
                    for (int i = 0; i < FirstArray.size; i++)
                    {
                        Console.WriteLine(ListArrays[1].array[i]);
                    }
                }
            }
            Console.Write("Request 6: ");
            Console.WriteLine("array with the largest sum of elements:");
            var request6 = from array in ListArrays
                           where (array.array[0] + array.array[1] < array.array[2])
                           select array;
            foreach (object array in request6)
            {
                if (array.Equals(FirstArray))
                {
                    Console.WriteLine("First array:");
                    for (int i = 0; i < FirstArray.size; i++)
                    {
                        Console.WriteLine(ListArrays[0].array[i]);
                    }
                }
                if (array.Equals(SecondArray))
                {
                    Console.WriteLine("Second array:");
                    for (int i = 0; i < FirstArray.size; i++)
                    {
                        Console.WriteLine(ListArrays[1].array[i]);
                    }
                }
            }
            Console.Write("Request 7: ");
            Console.WriteLine("minimum array ");
            var request7 = from array in ListArrays
                           where (array.array[0] > array.array[1])
                           select array;
            foreach (object array in request7)
            {
                if (array.Equals(FirstArray))
                {
                    Console.WriteLine("First array:");
                    for (int i = 0; i < FirstArray.size; i++)
                    {
                        Console.WriteLine(ListArrays[0].array[i]);
                    }
                }
                if (array.Equals(SecondArray))
                {
                    Console.WriteLine("Second array:");
                    for (int i = 0; i < FirstArray.size; i++)
                    {
                        Console.WriteLine(ListArrays[1].array[i]);
                    }
                }
            }
            Console.WriteLine("Request 8:");
            Console.Write("Count of equal arrays: ");
            var request8 = (from array in ListArrays
                            where (FirstArray.size == SecondArray.size)
                            select array).Count();
            Console.WriteLine(request8);
        }
    }
}
