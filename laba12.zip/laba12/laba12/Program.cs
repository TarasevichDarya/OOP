﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.IO;

namespace lab12
{
    public delegate void SomeDelegate();
    class User
    {
        public event SomeDelegate Upgrade;
        public event SomeDelegate Work;
        public void CommandUpgrade()
        {
            Console.WriteLine("Upgrade");
            if (Upgrade != null)
                Upgrade();
        }
        public void CommandWork()
        {
            Console.WriteLine("Work");
            if (Work != null)
                Work();
        }
    }
    class FirstReactionOnEvent
    {
        public void OnUprage()
        {
            Console.WriteLine("Upgrading version...");
        }
        public void OnWork()
        {
            Console.WriteLine("Displaying Message");
        }
    }
    class SecondReactionOnEvent
    {
        public void OnWork()
        {
            Console.WriteLine("Displayed Message");
        }
        public void OnUprage()
        {
            Console.WriteLine("Upgraded version...");
        }
    }
    public class Reflector<T>
    {
        string Infromation;
        public void Output()
        {
            string AllInformation = Infromation;
            using (FileStream fstream = new FileStream("D:\\AllInformationAboutClass.txt", FileMode.OpenOrCreate))
            {
                byte[] array = System.Text.Encoding.Default.GetBytes(AllInformation);
                fstream.Write(array, 0, array.Length);
                Console.WriteLine("File created.Information about class is written");
            }
        }
        public void AllInformation(T a)
        {
            Type typeA = a.GetType();
            MemberInfo[] memberInfo = typeA.GetMembers();
            foreach (object objects in memberInfo)
            {
                Console.WriteLine(objects);
                Infromation += (objects.ToString() + "\r\n");
            }
        }
        public void InfoAboutMethod(T a)
        {
            Type typeA = a.GetType();
            foreach (MethodInfo objects in typeA.GetMethods())
            {
                Console.WriteLine(objects);
            }
        }
        public void InfoAboutFieldsProperties(T a)
        {
            Type typeA = a.GetType();
            foreach (FieldInfo objects in typeA.GetFields())
            {
                Console.WriteLine(objects);
            }
            foreach (PropertyInfo objects in typeA.GetProperties())
            {
                Console.WriteLine();
            }
        }
        public void InfoAboutInterface(T a)
        {
            Type typeA = a.GetType();
            foreach (Type objects in typeA.GetInterfaces())
            {
                Console.WriteLine(objects);
            }
        }
        public void InfoAboutParameters(T a, string b)
        {
            Type typeA = a.GetType();
            MethodInfo[] methodInfo = typeA.GetMethods();
            foreach (MethodInfo objects in methodInfo)
            {
                ParameterInfo[] parameterInfo = objects.GetParameters();
                for (int i = 0; i < methodInfo.Length; i++)
                {
                    if ((parameterInfo[i].ParameterType.Name) == b)
                    {
                        Console.WriteLine(objects.Name + " " + parameterInfo[i].ParameterType.Name + " ");

                    }
                }
            }

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("All information about class:");
            Reflector<User> reflector1 = new Reflector<User>();
            User user1 = new User();
            reflector1.AllInformation(user1);
            Console.WriteLine();
            reflector1.Output();
            Console.WriteLine();
            Console.WriteLine("Information about methods:");
            Reflector<User> reflector2 = new Reflector<User>();
            User user2 = new User();
            reflector2.InfoAboutMethod(user2);
            Console.WriteLine();
            Console.WriteLine("Information about fields and properties:");
            Reflector<User> reflector3 = new Reflector<User>();
            User user3 = new User();
            reflector3.InfoAboutFieldsProperties(user3);
            Console.WriteLine();
            Console.WriteLine("Information about interface:");
            Reflector<User> reflector4 = new Reflector<User>();
            User user4 = new User();
            reflector4.InfoAboutInterface(user4);
            Console.WriteLine();
            Console.WriteLine("Information about parameters:");
            Reflector<User> reflector5 = new Reflector<User>();
            User user5 = new User();
            reflector5.InfoAboutFieldsProperties(user5);
        }
    }
}

