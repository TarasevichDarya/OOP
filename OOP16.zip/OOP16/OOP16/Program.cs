﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Collections.Concurrent;

namespace OOP16
{

    class Program
    {

        public static int ses = 100000;

        public static int sum = 0;

        static void Display(Task t)
        {
            Console.WriteLine("Id задачи: {0}", Task.CurrentId);
            Console.WriteLine("Id предыдущей задачи: {0}", t.Id);
            Thread.Sleep(3000);
        }

        public static void Eratosfera()
        {
            Stopwatch stopWatch1 = new Stopwatch();
            stopWatch1.Start();
            Console.Write("Простые числа: ");
            for (int i = 0; i <= ses; i++)
                if (Eratosfenb(i))
                {
                    Console.Write("{0} ", i);
                }
            stopWatch1.Stop();
            TimeSpan ts = stopWatch1.Elapsed;
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10);
            Console.WriteLine("RunTime " + elapsedTime);
        }

        public static int Odin()
        {
            for (int i = 0; i <= ses; i++)
            {
                if (Eratosfenb(i))
                {
                    sum += i;
                }
            }
            return sum;
        }

        public static int Dva()
        {
            for (int i = 0; i <= ses; i++)
            {
                if (Eratosfenb(i))
                {
                    sum += 2 * i;
                }
            }
            return sum;
        }

        public static int Tri()
        {
            for (int i = 0; i <= ses; i++)
            {
                if (Eratosfenb(i))
                {
                    sum += 3 * i;
                }
            }
            return sum;
        }

        public static bool Eratosfenb(double x)
        {
            double sqrtX = Math.Sqrt(x);
            for (int i = 2; i <= sqrtX; i++)
                if (x % i == 0) return false;
            return true;
        }

        static void Display()
        {
            Console.WriteLine("Начало работы метода Display");

            Console.WriteLine("Завершение работы метода Display");
        }

        static async Task FucktorialChisla5()
        {
            int num = 5;

            int result = await FactorialAsync(num);
            Thread.Sleep(3000);
            Console.WriteLine("Факториал числа {0} равен {1}", num, result);
        }

        public static async Task<int> FactorialAsync(int x)
        {
            int result = 1;

            return await Task.Run(() =>
            {
                for (int i = 1; i <= x; i++)
                {
                    result *= i;
                }
                return result;
            });
        }

        public static void Factorial(int x)
        {
            int result = 1;

            for (int i = 1; i <= x; i++)
            {
                result *= i;
            }
            Console.WriteLine("Выполняется задача {0}", Task.CurrentId);
            Console.WriteLine("Факториал числа {0} равен {1}", x, result);
            Thread.Sleep(3000);
        }

        static void Main(string[] args)
        {

            CancellationTokenSource cancelTokenSource = new CancellationTokenSource();
            CancellationToken Tekken = cancelTokenSource.Token;

            Console.WriteLine("Введите Y для отмены операции или другой символ для ее продолжения:");
            string s = Console.ReadLine();
            if (s == "Y")
                cancelTokenSource.Cancel();



            var inner = Task.Factory.StartNew(() =>  // вложенная задача
            {
                Thread.Sleep(3000);
                Task Efectosfer = Task.Run(() => Eratosfera());
                if (Tekken.IsCancellationRequested)
                {
                    Console.WriteLine("Операция прервана");
                    return;
                }
                Console.WriteLine("Cherez vnutrenniy potok delaem");
                Console.WriteLine("ID: " + Efectosfer.Id);
                Console.WriteLine("Status " + Efectosfer.Status);
                Console.WriteLine("Status Gotovnosti " + Efectosfer.IsCompleted);
                Console.WriteLine("Inner task finished.");
            });




            var outer = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Outer task starting...");
                var tda = Task.Factory.StartNew(() =>
                {
                    Console.WriteLine("Inner task starting...");
                    Thread.Sleep(2000);
                    Console.WriteLine("Inner task finished.");
                });
            });
            outer.Wait();

            Task<int> Zadacha1 = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Pervoe Vichislenie nachalos");
                int ses1 = Odin();
                return ses1;
            });

            Task<int> Zadacha2 = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Vtoroe Vichislenie nachalos");
                int ses2 = Dva();
                return ses2;
            });

            Task<int> Zadacha3 = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Tretee Vichislenie nachalos");
                int ses3 = Tri();
                return ses3;
            });

            Zadacha1.Wait();
            Zadacha2.Wait();
            Zadacha3.Wait();

            var Zadacha4 = Task.Factory.StartNew(() =>
            {
                Console.WriteLine(Zadacha1.Result + Zadacha2.Result / Zadacha3.Result);
            });

            Task Zadacha5 = Zadacha4.ContinueWith(Display);


            FucktorialChisla5().GetAwaiter().GetResult();
            Console.WriteLine("Задача завершена tak skozatb");




            Parallel.For(1, 10000, Factorial);
            ParallelLoopResult Rizalt = Parallel.ForEach<int>(new List<int>() { 1, 3, 5, 8, 6996, 7788 }, Factorial);
            Parallel.Invoke(Display);


            var postavshik1 = Task.Factory.StartNew(() =>  // вложенная задача
            {
                Thread.Sleep(3000);

            });

            Magazin = new BlockingCollection<string>(20);

            Task P1 = new Task(Postavshik1);
            Task P2 = new Task(Postavshik2);
            Task P3 = new Task(Postavshik3);
            Task P4 = new Task(Postavshik4);
            Task P5 = new Task(Postavshik5);
            P1.Start();
            P2.Start();
            P3.Start();
            P4.Start();
            P5.Start();

            Task Poquateli = Task.Factory.StartNew(() =>
            {
                Pokupatel();
                Pokupatel();
                Pokupatel();
                Pokupatel();
                Pokupatel();
                Pokupatel();
                Pokupatel();
                Pokupatel();
                Pokupatel();
                Pokupatel();
            });




            Console.ReadLine();

        }

        public static BlockingCollection<string> Magazin;

        static void Postavshik1()
        {
            for (int i = 0; i < 5; i++)
            {
                Thread.Sleep(3000);
                Magazin.Add(" Holodilnik");
                Console.WriteLine("Zavezli Televizor");

            }
        }

        static void Postavshik2()
        {
            for (int i = 0; i < 5; i++)
            {
                Thread.Sleep(600);
                Magazin.Add("Televizor");
                Console.WriteLine("Zavezli Televizor");
            }
        }

        static void Postavshik3()
        {
            for (int i = 0; i < 5; i++)
            {
                Thread.Sleep(500);
                Magazin.Add("Divan");
                Console.WriteLine("Zavezli Divan");
            }
        }

        static void Postavshik4()
        {
            for (int i = 0; i < 5; i++)
            {
                Thread.Sleep(500);
                Magazin.Add("Stul");
                Console.WriteLine("Zavezli Stul");
            }
        }

        static void Postavshik5()
        {
            for (int i = 0; i < 5; i++)
            {
                Thread.Sleep(300);
                Magazin.Add("Stol");
                Console.WriteLine("Zavezli Stol");
            }
        }

        static void Pokupatel()
        {
            string i;
            Thread.Sleep(2000);
            while (!Magazin.IsCompleted)
            {
                if (Magazin.TryTake(out i))
                    Console.WriteLine("Kupili tovar : " + i);
                else break;
            }
            
        }

    }
}
