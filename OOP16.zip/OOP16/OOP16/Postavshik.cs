﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP16
{
    class Postavshik
    {
        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        

        public Postavshik(string a)
        {
            this.Name = a;
        }
    }
}
