﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboratornaya2oop
{
    class Program
    {
        static void Main(string[] args)
        {
            //1a
            int i1 = 10;
            double d = 123.456;
            short sh = -111;
            sbyte sb = 4;
            long l = 3466;
            byte b = 255;
            ushort ush = 3433;
            uint ui = 1234;
            ulong ul = 3234;
            char c = 'D';
            bool br = true;
            float f = 34.54F;
            object obb1 = new object();
            string str1 = "Hello";
            decimal d23 = 123.34M;

            //1b
            Console.WriteLine("1 b : ");
            int b1 = 10;
            float b2 = b1; //неявное приведение
            double b3 = b2;
            decimal b4 = b1;
            Console.WriteLine(b4);
            short b5 = 23;
            long b6 = b5;
            char b7 = '2';
            Console.WriteLine(b7.ToString());
            int b8 = b7;
            Console.WriteLine(b8 + "\n");

            byte nb1 = 12;
            int nb2 = (byte)nb1; //явное приведение
            float nb3 = (int)nb2;
            double nb4 = (float)nb3;
            Console.WriteLine(nb4);
            short nb6 = 32;
            long nb7 = (short)nb6;
            float nb8 = (long)nb7;
            Console.WriteLine(nb8);

            //1c
            Console.WriteLine("1 c : ");
            int number = 123;
            object obj = number; //boxing
            Console.WriteLine(obj);
            float unboxed = (float)(int)obj; //unboxing
            Console.WriteLine(unboxed);


            //1d
            Console.WriteLine("1 d : ");
            var text = "Hello sweety!";
            Console.WriteLine(text);
            var num = 34;
            Console.WriteLine(num);


            //1e
            Console.WriteLine("1 e : ");
            Nullable<int> test = 22;
            test = test / 2;
            Console.WriteLine(test);
            test = null;
            Console.WriteLine(test);


            //2a
            Console.WriteLine("2 a : ");
            string Firststr = "Kitties";
            string Secondstr = "Dogs";
            Console.WriteLine(Firststr == Secondstr); //проверка на равенство

            string Thirdstr = "dasha";
            string Fourthstr = "lesha";
            Console.WriteLine(String.Compare(Thirdstr, Fourthstr)); //сравнение 2 строк в алфавитном порядке


            //2b
            Console.WriteLine("2 b : ");
            string strnumber1 = "You are";
            string strnumber2 = "So";
            string strnumber3 = "Beautiful";
            Console.WriteLine(strnumber1 + " " + strnumber2 + " " + strnumber3 + "\n"); //сцепление

            Console.WriteLine(strnumber1.Clone() + "\n");

            string strnumber4 = "Everything will be okey";
            string strnumber5 = "Cute! ";
            string substring = "Badbadbad!";
            Console.WriteLine(strnumber4.Substring(5, 7) + "\n"); //Выделение подстроки

            string[] words = strnumber4.Split(new char[] { ' ' });
            //разделение на  слова
            foreach (string s in words) //для перебора эл-тов в контейнерах и массивах
            {
                Console.WriteLine(s);
            }

            Console.WriteLine("\n" + strnumber5.Insert(6, substring)); //вставка подстроки в заданную позицию

            Console.WriteLine("\n" + strnumber5.Substring(4)); //удаление подстроки

            //2c
            Console.WriteLine("2 c : ");
            string Emptystr = "";
            string nullablestr = null;
            Emptystr = strnumber5;
            Console.WriteLine(Emptystr);
            nullablestr = substring;
            Console.WriteLine(nullablestr);

            //2d
            Console.WriteLine("2 d : ");
            StringBuilder alsostr = new StringBuilder("Water, water in the sea, go home");
            Console.WriteLine(alsostr.Remove(0, 6)); //удаление подстр с зад символа
            Console.WriteLine(alsostr.Insert(0, "Hey!"));
            Console.WriteLine(alsostr.Insert(alsostr.Length, " Ahahahah"));

            //3a
            Console.WriteLine("3 a : ");
            int[,] array = new int[3, 5]; //прямоуг массив 
            Random random = new Random();
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    array[i, j] = random.Next(0, 50);
                    Console.Write("{0}\t", array[i, j]);
                }
                Console.WriteLine();
            }
            //3b
            Console.WriteLine("3 b : ");
            string[] strArray = new string[3];
            strArray[0] = "Leila";
            strArray[1] = "This is love";
            strArray[2] = "Lambada";

            for (int i = 0; i < 3; i++)
            {
                Console.Write("{0}\t", strArray[i]);
            }

            Console.WriteLine("\n" + strArray.Length.ToString());

            strArray[2] = "I love my car!";
            for (int i = 0; i < 3; i++)
            {
                Console.Write("{0}\t", strArray[i]);
            }

            //3c
            Console.WriteLine("\n" + "3 c : ");
            int[][] alsoArray = new int[3][];
            alsoArray[0] = new int[2];
            alsoArray[1] = new int[3];
            alsoArray[2] = new int[4];


            Console.WriteLine();

            for (int i = 0; i < 2; i++)
            {
                alsoArray[0][i] = i;
                Console.Write("{0}\t", alsoArray[0][i]);
            }

            Console.WriteLine();
            for (int i = 0; i < 3; i++)
            {
                alsoArray[1][i] = i;
                Console.Write("{0}\t", alsoArray[1][i]);
            }

            Console.WriteLine();
            for (int i = 0; i < 4; i++)
            {
                alsoArray[2][i] = i;
                Console.Write("{0}\t", alsoArray[2][i]);
            }

            //3d
            Console.WriteLine("\n" + " 3 d : ");
            var varArray = new[] { 7, 43, 23, 60, 15 };
            for (int i = 0; i < varArray.Length; i++)
            {
                Console.Write("{0}\t", varArray[i]);
            }

            var varStrArray = new[] { "No love", "in", "my heart" };
            Console.WriteLine();
            for (int i = 0; i < varStrArray.Length; i++)
            {
                Console.Write("{0}\t", varStrArray[i]);
            }

            //4a
            Tuple<int, string, char, string, ulong> cortaje; //комбинирует обьекты разл типов от 1 до 8
            
            //4b
            int firstEl = 23;
            string secondEl = "Love";
            char thirdEl = 'D';
            string fourthEl = "No love";
            ulong fifthEl = 15;

            cortaje = new Tuple<int, string, char, string, ulong>(firstEl, secondEl, thirdEl, fourthEl, fifthEl);

            //4c
            Console.WriteLine("\n" + " 4 c : ");
            Console.WriteLine(cortaje);
            Console.WriteLine("{0} {1} {2}", cortaje.Item1, cortaje.Item3, cortaje.Item4);

            //Item1  ... - по умолчанию

            //4d
            int unboxedFirstEl = (int)cortaje.Item1;//распаковка кортежа
            string unboxedSecondEl = (string)cortaje.Item2;
            char unboxedThirdEl = (char)cortaje.Item3;
            string unboxedFourthEl = (string)cortaje.Item4;
            ulong unboxedFifthEl = (ulong)cortaje.Item5;

            //4e
            Console.WriteLine("4 e : ");
            Tuple<int, char> secondCortaje = new Tuple<int, char>(34, 'd');
            Tuple<char, string> thirdCortaje = new Tuple<char, string>('a', "Bye,my love.");
            Console.WriteLine(Object.Equals(secondCortaje, thirdCortaje));//сравнение двух кортежей

            //5
            //(int, int, int, char) LocFun(int[] array, string s)
            //{
            //    int max = 0, min = 0, sum = 0;
            //    char letter;
            //    for (i = 1; i < array.Length; i++)
            //        if (array[max] < array[i])
            //            max = i;
            //    for (i = 1; i < array.Length; i++)
            //        if (array[min] > array[i])
            //            min = i;
            //    for (i = 0; i < array.Length + 1; i++)
            //        sum += i;
            //    letter = s[0];

            //    return (array[max], array[min], sum, letter);
            //}

            //var cor = LocFun(vmas, s1);
            //Console.WriteLine($"{cor}");
            //*/

            Console.Read();
        }
    }
}
