﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Создать класс – Треугольник, заданного тремя точками(Создать класс Point). 
//Методы класса обеспечивают вывод на экран координат, рассчитывают длины сторон и периметр треугольника.Создать массив объектов.
//a) подсчитать количество треугольников разного типа(равносторонний, равнобедренный, прямоугольный, произвольный).
//b) определить для каждой группы наибольший и наименьший по периметру объект.

namespace laboratornaya3oop
{
    class Program
    {
        static void Main(string[] args)
        {
            int countRavnobedr = 0;
            int countRavnost = 0;
            int countPryamoug = 0;
            int countProizvol = 0;
            Triangle[] ArrayTest = new Triangle[6]; //массив обьектов
            ArrayTest[0] = new Triangle(new Point(3,3), new Point(3,8), new Point (10,7));
            ArrayTest[1] = new Triangle(new Point(1, 1), new Point(1, 6), new Point(4, 1));
            ArrayTest[2] = new Triangle(new Point(4, 2), new Point(8, 2), new Point(6, 9));
            ArrayTest[3] = new Triangle(new Point(5, 2), new Point(5, 8), new Point(9, 5));
            ArrayTest[4] = new Triangle(new Point(0, 0), new Point(0, 1), new Point(2, 0));
            ArrayTest[5] = new Triangle(new Point(0, 0), new Point(1, 1), new Point(0, 2));

            var someType = new { Name = "Dasha" };//аноним типы ?

            double min = 0, max = 0 ;
            
            for (int i = 0; i < ArrayTest.Length; i++)
            {

                ArrayTest[i].OutPointTriange();
                ArrayTest[i].OutLengthSide();
                double x = 0;
                if (ArrayTest[i].PerimetrTriangle() > max)
                    max = ArrayTest[i].PerimetrTriangle();
                if (ArrayTest[i].PerimetrTriangle() < min)
                    min = ArrayTest[i].PerimetrTriangle();


                if (RavnobedrTriangle(ArrayTest[i]))
                    countRavnobedr++;
                if (RavnostTriangle(ArrayTest[i]))
                    countRavnost++;
                if (PryamougTriangle(ArrayTest[i]))
                    countPryamoug++;
                if (ProizvolniyTriangle(ArrayTest[i]))
                    countProizvol++;
            }
            
            Console.WriteLine("Pavnobedrennih : " + countRavnobedr + '\n');
            Console.WriteLine("Ravnostoronnih : " + countRavnost + '\n');
            Console.WriteLine("Pryamougolnih : " + countPryamoug + '\n');
            Console.WriteLine("Proizvolnih : " + countProizvol + '\n');

            Console.WriteLine("Max : " + max + '\n');
            Console.WriteLine("Min : " + min + '\n');
            Console.WriteLine("Count triangle (static) : " + Triangle.countTriangle);//вывод кол-ва созд классов

            bool RavnostTriangle(Triangle testTriangle)
            {
                if (testTriangle.LengthSide1() == testTriangle.LengthSide2() && testTriangle.LengthSide1() == testTriangle.LengthSide3())
                    //Console.WriteLine("Ravnostoronnii triangle" + '\n');
                    return true;
                else
                    //Console.WriteLine("Not ravnostoronnii triangle" + '\n');
                    return false;
            }
            
            bool RavnobedrTriangle(Triangle testTriangle)
            {
                if (testTriangle.LengthSide1() == testTriangle.LengthSide2() || testTriangle.LengthSide1() == testTriangle.LengthSide3() || testTriangle.LengthSide2() == testTriangle.LengthSide3())
                    //Console.WriteLine("Ravnobedrennii triangle" + '\n');
                    return true;
                else
                    //Console.WriteLine("Not ravnobedrennii triangle" + '\n');
                    return false;
            }

            bool PryamougTriangle(Triangle testTriangle)
            {
                double gip=0, cat1, cat2;
                testTriangle.BigSide(ref gip, out cat1, out cat2);
                if (gip * gip == (cat1 * cat1 + cat2 * cat2))
                    //Console.WriteLine("Pryamougolniy triangle" + '\n');
                    return true;
                else
                    //Console.WriteLine("Not pryamougolniy triangle" + '\n');
                    return false;

            }

            bool ProizvolniyTriangle(Triangle testTriangle)
            {
                if (testTriangle.LengthSide1() != testTriangle.LengthSide2() && testTriangle.LengthSide1() != testTriangle.LengthSide3() && testTriangle.LengthSide2() != testTriangle.LengthSide3())
                {
                    //Console.WriteLine("Proizvolniy triangle" + '\n');
                    return true;
                }
                else
                { 
                    //Console.WriteLine("Not proizvolniy triangle" + '\n');
                    return false;
                }
            }

            Console.Read();
        }
    }
}
