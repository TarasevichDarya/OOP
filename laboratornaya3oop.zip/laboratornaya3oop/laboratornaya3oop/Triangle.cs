﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboratornaya3oop
{
    class Triangle
    {
        private Point x; //три поля класса поинт
        private Point y;
        private Point z;
        public static int countTriangle = 0; //статич поле
        public Triangle()//по умолч, без парам
        {
            x = new Point(0, 0);//маленький треуг,произв
            y = new Point(4, 3);
            z = new Point(4, 0);
        }

        public Triangle(Point firstPoint, Point secondPoint, Point thirdPoint)
        {
            x = firstPoint;
            y = secondPoint;
            z = thirdPoint;
            countTriangle++;
        }

        static Triangle() //статич конструктор
        {
            Console.WriteLine("New Triangle\n");
        }

        static void GetInfo()//вывод номера класса
        {
            Console.WriteLine(countTriangle);
        }

        public void OutPointTriange()//метод вывода в консоль коорд точек
        {
            Console.WriteLine("x : (" + x.X + "," + x.Y + ")" + "\n");
            Console.WriteLine("y : (" + y.GetX() + "," + y.GetY() + ")" + "\n");
            Console.WriteLine("z : (" + z.GetX() + "," + z.GetY() + ")" + "\n");
        }

        public override int GetHashCode()       // свой хэш
        {
            int unitCode;
            if (x.X == 0)
                unitCode = 1;
            else unitCode = 2;
            return y.Y + unitCode;
        }


        public override bool Equals(System.Object obj)
        {
            if (obj == null)
            {
                return false;
            }

            // If parameter cannot be cast to Point return false.
            Triangle p = obj as Triangle;
            if ((System.Object)p == null)
            {
                return false;
            }

            // Return true if the fields match:
            return (x == p.x) && (y == p.y);
        }


        public static string ToString(System.Object obj)
        {
            if (obj == null)
            {
                return "nil";
            }

            // If parameter cannot be cast to Point return false.
            Triangle p = obj as Triangle;
            if ((System.Object)p == null)
            {
                return "nil";
            }

            return p.x.ToString() + ":" + p.y.ToString();
        }

        public double LengthSide1()//длина сторон
        {
            return (Math.Sqrt((y.GetX() - x.GetX()) ^ 2 + (y.GetY() - x.GetY()) ^ 2));
        }

        public double LengthSide2()//длина сторон
        {
            return ((Math.Sqrt((z.GetX() - y.GetX()) ^ 2 + (y.GetY() - z.GetY()) ^ 2)));
        }

        public double LengthSide3()//длина сторон
        {
            return Math.Sqrt((z.GetX() - x.GetX()) ^ 2 + (z.GetY() - x.GetY()) ^ 2);
        }

        public double PerimetrTriangle()//периметр треуг
        {
            return (LengthSide1() + LengthSide2() + LengthSide3());
           
        }

        public void OutLengthSide()//вывод длины сторон треуг
        {
            Console.WriteLine("Length : " + LengthSide1() + "\n");
            Console.WriteLine("Length : " + LengthSide2() + "\n");
            Console.WriteLine("Length : " + LengthSide3() + "\n");
        }

        public void OutPerimetrTriangle()
        {
            Console.WriteLine("Perimetr : " + PerimetrTriangle());
        }

        public void BigSide(ref double gipot, out double cat1, out double cat2)
        {
            if (LengthSide1() > LengthSide2() && LengthSide1() > LengthSide3())
            {
                gipot = LengthSide1();
                cat1 = LengthSide2();
                cat2 = LengthSide3();
            }
            if (LengthSide2() > LengthSide1() && LengthSide2() > LengthSide3())
            {
                gipot = LengthSide2();
                cat1 = LengthSide1();
                cat2 = LengthSide3();
            }
            if (LengthSide3() > LengthSide1() && LengthSide3() > LengthSide2())
            {
                gipot = LengthSide3();
                cat1 = LengthSide2();
                cat2 = LengthSide1();
            }
            else
            {
                gipot = 0;
                cat1 = 0;
                cat2 = 0;
            }
        }
    }
}
