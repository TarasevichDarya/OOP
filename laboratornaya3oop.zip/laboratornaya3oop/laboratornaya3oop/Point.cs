﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboratornaya3oop
{
    class Point
    {
        private int x;
        private int y;

        public int X //установка гет и сет
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public int Y //установка гет и сет
        {
            get
            {
                return y;
            }
        }

        public partial class Student //класс партиал
        {
            public readonly int Dasha = 23;
            const string Name = "Dasha";
        }
        public sealed partial class Student {
            public Student()
            {

            }

        }
       

        private Point() { }//закрытый конструктор 

        public Point(int point_x, int point_y)
        {
            x = point_x;
            y = point_y;
        }

        public Point(Point newPoint)
        {
            x = newPoint.GetX();
            y = newPoint.GetY();

        }
        public int GetX()//коорд точек
        {
            return x;
        }

        public int GetY()
        {
            return y;
        }
        
    }
}
