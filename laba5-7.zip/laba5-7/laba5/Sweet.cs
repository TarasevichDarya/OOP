﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba5
{
    public partial class Cookies : Pastry
    {
        public override string ToString()
        {
            return string.Format("[Cookies]");
        }
    }
}
