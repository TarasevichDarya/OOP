﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

/*Кондитерское изделие, Конфета, Карамель, Шоколадная
конфета, Печенюшка, Коробка конфет.*/

/*Собрать Детский подарок с определением его веса. Провести
сортировку конфет в подарке на основе одного из
параметров. Найти конфету в подарке, соответствующую
заданному диапазону содержания сахара.
 */
public enum eWeight { light, medium, heavy }
public enum eSugar { small, medium, big }

public struct SItem
{
    public string Name;
    public eWeight weight;
    public eSugar sugar;
    
    public SItem(string q, eWeight w, eSugar e)
    {
        Name = q;
        weight = w;
        sugar = e;
    }
    public bool Show()
    {
        if (Name == null)
            return false;
        Console.Write("I am " + Name + " " + (int)weight + " " + (int)sugar);
        if ((int)weight > 1)
            Console.WriteLine(". I am fat:( ");
        else if ((int)weight == 1)
            Console.WriteLine(" . I am normal :|");
        else
            Console.WriteLine(" . I am easy:)");
        return true;
    }
}

public class KidsGift
{
    SItem[] box;
    int countt;
    public KidsGift(int count)
    {
        box = new SItem[count];
        countt = count;
    }
    public void Add(int pos, string s, eWeight w, eSugar e)
    {
        box[pos] = new SItem(s, w, e);
    }
    public SItem this[int i]
    {
        get
        {
            return box[i];
        }
        set
        {
            box[i] = value;
            Debug.Assert(i>=0, "i cannot be smaller then 0");
        }
    }
    public bool Delete(int pos)
    {
        for(int i = pos; i < countt-1; i++)
        {
            box[i] = box[i + 1];
        }
        return true;
    }
    public void Show()
    {
        for (int i = 0; i < countt; i++)
            box[i].Show();
        Console.WriteLine();
    }
}

public class ControlGift
{
    public KidsGift k;
    public int countt;
    public ControlGift(int count)
    {
        countt = count;
        k = new KidsGift(count);
    }
    public void SortWeight()
    {
        for(int i=0; i<countt-1;i++)
        {
            for(int j=0; j<countt-1;j++)
            {
                if((int)k[j].weight > (int)k[j+1].weight)
                {
                    SItem temp;
                    temp = k[j];
                    k[j] = k[j+1];
                    k[j + 1] = temp;
                }
            }
        }
    }
    public void SortSugar()
    {
        for (int i = 0; i < countt - 1; i++)
        {
            for (int j = 0; j < countt - 1; j++)
            {
                if ((int)k[j].sugar > (int)k[j + 1].sugar)
                {
                    SItem temp;
                    temp = k[j];
                    k[j] = k[j + 1];
                    k[j + 1] = temp;
                }
            }
        }
    }
}

public abstract class BeforePastry
{
    public string Name;
    public abstract void SetName(string s);
}

public class MyException : System.Exception
{
    public MyException() : base() { }
    public MyException(string massage) : base(massage) { }
}

public class OutOfRange : System.Exception
{
    public OutOfRange(string massage) : base("afdfs"+massage) { }
}

public class ZeroDelition : System.Exception
{
    public ZeroDelition() : base() { }
    public ZeroDelition(string massage) : base("zero"+massage) { }
}

public class Pastry : BeforePastry, iDo
{
    public string TypeP = "prime";
    public Pastry()
    { }
    public override void SetName(string s)
    {
        Name = s;
    }
    public Pastry(string d)
    {
        SetName(d);
    }
    public void Show()
    {
        Console.WriteLine("This is : " + TypeP + " " + Name);
    }
    public override string ToString()
    {
        return string.Format("[Pastry]");
    }
}

class Sweet : Pastry
{
    public Sweet()
    {
        SetName("Sweet");
    }
    public override string ToString()
    {
        return string.Format("[Sweet]");
    }
}

class Caramel : Pastry
{
    public Caramel()
    {
        SetName("Caramel");
    }
    public override string ToString()
    {
        return string.Format("[Caramel]");
    }
    public override int GetHashCode()
    {
        return Name.GetHashCode() + Name.Length.GetHashCode();
    }
    public override bool Equals(object obj)
    {
        if (obj == null)
            return false;
        if (this.GetType() != obj.GetType())
            return false;
        else
            return true;
    }
}

class ChocolateSweet : Sweet
{
    public ChocolateSweet()
    {
        TypeP = "Chocolate";
        SetName("Sweet");
    }
    public override string ToString()
    {
        return string.Format("[ChocolateSweet]");
    }
}

public partial class Cookies : Pastry
{
    public Cookies()
    {
        SetName("Cookies");
    }
}

sealed class BoxOfCookies : Pastry
{
    Cookies[] box;
    public BoxOfCookies(int x)
    {
        SetName("BoxOfCookies");
        box = new Cookies[x]; //массив с размером х
        for (int i = 0; i < x; i++)
            box[i] = new Cookies();
    }
    public override string ToString()
    {
        return string.Format("[BoxOfCookies]");
    }
}

interface iDo
{
    void Show();
}

class Printer
{
    public void iAmPrinting(iDo pr)
    {
        if (pr is BoxOfCookies == true)
            Console.WriteLine((pr as BoxOfCookies).ToString());
        else if (pr is ChocolateSweet == true)
            Console.WriteLine((pr as ChocolateSweet).ToString());
        else if (pr is Cookies == true)
            Console.WriteLine((pr as Cookies).ToString());
        else if (pr is Caramel == true)
            Console.WriteLine((pr as Caramel).ToString());
        else if (pr is Sweet == true)//если обьект класса свиt
            Console.WriteLine((pr as Sweet).ToString());
        else if (pr is Pastry == true)
            Console.WriteLine((pr as Pastry).ToString());
    }
}

namespace lab4oop
{
    class Program
    {
        static void Main(string[] args)
        {   //5
            //Printer prpr = new Printer();

            //Pastry p = new Pastry();
            //iDo kl = p;
            //kl.Show();
            //Sweet sw = new Sweet();
            //BeforePastry klkl = sw;
            //(klkl as Sweet).Show();

            //iDo[] array1 = new iDo[4];
            //array1[0] = new Sweet();
            //array1[1] = new Cookies();
            //array1[2] = new BoxOfCookies(5);
            //array1[3] = new ChocolateSweet();

            //foreach (iDo idoido in array1)
            //{
            //    prpr.iAmPrinting(idoido);
            //}

            //6
            //KidsGift k = new KidsGift(5);
            //ControlGift kk = new ControlGift(5);
            //k.Add(4, "sweet", eWeight.light, eSugar.small);
            //k.Add(1, "sweet", eWeight.medium, eSugar.medium);
            //k.Add(3, "sweet", eWeight.heavy, eSugar.big);
            //k.Add(2, "sweet", eWeight.heavy, eSugar.big);
            //k.Add(0, "sweet", eWeight.heavy, eSugar.big);

            ////k.Delete(1);
            //k.Show();
            //kk.k = k;
            //kk.SortSugar();
            //kk.k.Show();
            //kk.SortWeight();
            //kk.k.Show();

            //7
            try
            {
                KidsGift k = new KidsGift(5);
                ControlGift kk = new ControlGift(5);
                k.Add(4, "sweet", eWeight.light, eSugar.small);
                k.Add(1, "sweet", eWeight.medium, eSugar.medium);
                k.Add(3, "sweet", eWeight.heavy, eSugar.big);
                k.Add(2, "sweet", eWeight.heavy, eSugar.big);
                k.Add(0, "sweet", eWeight.heavy, eSugar.big);
                if (5 > kk.countt)
                    throw new OutOfRange("Fail");
                k.Add(5, "sweet", eWeight.medium, eSugar.medium);

                int h = 0;
                if (h == 0)
                    throw new ZeroDelition("Delenie na 0");
                throw new MyException("Cute");
                int x = 5 / h;

                //k.Delete(1);
                k.Show();
                kk.k = k;
                kk.SortSugar();
                kk.k.Show();
                kk.SortWeight();
                kk.k.Show();

                KidsGift mm = null;
                if (mm == null)
                    throw new MyException("KidsGift = null");


            }
            catch (ZeroDelition y)
            {
                Console.WriteLine(y.Message);
            }
            catch (OutOfRange x)
            {
                Console.WriteLine(x.Message);
            }
            catch (System.DivideByZeroException z)
            {
                Console.WriteLine(z.Message);
            }
            catch (MyException m)
            {
                Console.WriteLine(m.Message);
            }
            catch
            {
                Console.WriteLine("So cute");
            }
            finally
            {
                Console.WriteLine("Finally Exception");
            }
        }
    }
}