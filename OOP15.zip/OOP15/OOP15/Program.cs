﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using System.IO;

namespace OOP15
{
    class Program
    {
        static int SuperNumber = 1;

        static Mutex Oroceceron = new Mutex();

        static int n = 10;

        static object locker = new object();

        private static void SecondaryDomain_DomainUnload(object sender, EventArgs e)
        {
            Console.WriteLine("Домен выгружен из процесса");
        }

        private static void Domain_AssemblyLoad(object sender, AssemblyLoadEventArgs args)
        {
            Console.WriteLine("Сборка загружена");
        }

        private static void Superrr()
        {
            for(int i = 0; i < n; i++)
            {
                if (i == 2) { Console.WriteLine("Prioritet: "+Thread.CurrentThread.Priority); }
                if (i == 3) { Console.WriteLine("ID: "+Thread.CurrentThread.ManagedThreadId); }
                if (i == 4) { Console.WriteLine("Name: " + Thread.CurrentThread.Name); }
                if (i == 5) { Console.WriteLine("Status: " + Thread.CurrentThread.IsAlive); }

             Thread.Sleep(1000);
             Console.WriteLine("Potok vivodit " + i);
      
            }
        }
    
        private static void NambaOne()
        {
            do
            {
                Oroceceron.WaitOne();
                Thread.Sleep(1500);
                if (SuperNumber % 2 == 1)
                {
                Console.WriteLine("Potok 1 vivodit " + SuperNumber);
                    if (SuperNumber < n)
                    {
                        File.AppendAllText("D:\\SAS.txt", SuperNumber + " ");
                        SuperNumber++;
                    }
                    else
                    {
                        Thread.CurrentThread.Suspend();
                    }
                }
                Oroceceron.ReleaseMutex();
            }
            while (SuperNumber  <= n);
        }

        private static void NambaTwo()
        {
            do
            {
                Oroceceron.WaitOne();
                Thread.Sleep(2500);
                if (SuperNumber % 2 == 0)
                {
                 Console.WriteLine("Potok 2 vivodit " + SuperNumber);
                    if (SuperNumber < n)
                    {
                        File.AppendAllText("D:\\SAS.txt", SuperNumber + " ");
                        SuperNumber++;
                    }
                    else
                    {
                        Thread.CurrentThread.Suspend();
                    }
                }
                Oroceceron.ReleaseMutex();
            }
            while (SuperNumber <= n);
        }

        static void Main(string[] args)
        {

            foreach (Process process in Process.GetProcesses())
            {
                Console.WriteLine("ID: {0}  Name: {1}  StartTime: {2}  Priority: {3} ProcessorTime: {4} ", process.Id, process.ProcessName, process.StartTime, process.PriorityClass, process.TotalProcessorTime);
            }
            /////////////////////////2///////////////////////
            AppDomain domain = AppDomain.CurrentDomain;
            Console.WriteLine("Name: {0}", domain.FriendlyName);
            Console.WriteLine("Base Directory: {0}", domain.BaseDirectory);
            var infAsm = from asm in domain.GetAssemblies()
                         orderby asm.GetName().Name
                         select asm;
            foreach (var a in infAsm)
            {
                Console.WriteLine("-> Имя: \t{0}\n-> Версия: \t{1}", a.GetName().Name, a.GetName().Version);
            }




            AppDomain secondaryDomain = AppDomain.CreateDomain("Thuger");
            // событие загрузки сборки

            secondaryDomain.AssemblyLoad += Domain_AssemblyLoad;
            //// событие выгрузки домена

            secondaryDomain.DomainUnload += SecondaryDomain_DomainUnload;


            Console.WriteLine("Домен: {0}", secondaryDomain.FriendlyName);
            secondaryDomain.Load(new AssemblyName("System.Data"));
            Assembly[] assemblies = secondaryDomain.GetAssemblies();
            foreach (Assembly asm in assemblies)
                Console.WriteLine(asm.GetName().Name);
            // выгрузка домена
            AppDomain.Unload(secondaryDomain);




            Thread Potoq = new Thread(Superrr);
            Potoq.Name = "Potok obichniy";
            Potoq.Start();
            Potoq.Suspend();
            Potoq.Resume();

            Thread Thuger1 = new Thread(NambaOne);
            Thread Thuger2 = new Thread(NambaTwo);
            Thuger1.Start();
            Thuger2.Start();

            Thuger1.Priority = ThreadPriority.Highest;
            Thuger2.Priority = ThreadPriority.Lowest;

            TimerCallback timeCB = new TimerCallback(PrintTime);
            Timer time = new Timer(timeCB, null, 0, 1000);
            Console.ReadLine();

        }

        static void PrintTime(object state)
        {
            Console.Clear();
            Console.WriteLine("Текущее время:  " +
            DateTime.Now.ToLongTimeString());
        }

    }
}


