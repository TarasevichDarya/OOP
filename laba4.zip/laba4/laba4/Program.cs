﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace lab4oop
{
    /*Класс - стек Stack. 
    Дополнительно перегрузить следующие операции:
    + - добавить элемент в стек;
    — - извлечь элемент из стека; 
    true - проверка, пустой ли стек; 
    Методы расширения:
    1) Подсчет количества предложений
    2) Определение среднего элемента стека
    */
    public class Date
    {
        public String Value;
        public Date()
        {
            Value = System.DateTime.Now.ToString();
        }
    }

    public class TOwner
    {
        public int Id;
        public String Name, wCreate;

        public TOwner()
        {
            Id = 0;
            Name = "Dasha";
            wCreate = "Dasha Corporation";
        }

        public TOwner(int ID, String NAME, String WCREATE)
        {
            Id = ID;
            Name = NAME;
            wCreate = WCREATE;
        }

        public override string ToString()
        {
            return "ID: " + Id.ToString() + ", NAME: " + Name + ", WCREATE: " + wCreate;
        }
    }

    public class Stack
    {
        const int MAXCOUNT = 20;
        public int[] box = new int[MAXCOUNT];
        public int Count;
        public TOwner Owner = new TOwner();
        public Date DATE = new Date();

        public Stack()
        {
            Count = 0;
        }

        public Stack(int s)
        {
            Count = 1;
            box[0] = s;
        }

        public void Set(int elem, int value)
        {
            if (elem > -1 && elem < Count)
                box[elem] = value;
        }

        public int Get(int elem)
        {
            if (elem > -1 && elem < Count)
                return box[elem];
            return -1;
        }

        private bool check(int pos)
        {
            return (pos > -1 && pos < Count);
        }

        public void show() 
        {
            for (int i = 0; i < Count; Console.Write($"{box[i]} "), i++) ;
            Console.WriteLine();
        }

        public void moveAllAfter(int pos, int type) //сдвигаем вправо или влево эл мас
        {//1 or -1
            if (check(pos))
            {
                if (type == 1)//вправо
                {
                    for (int i = Count; i > pos; i--)
                        box[i] = box[i - 1];
                    box[pos] = 0;
                }
                else
                {
                    for (int i = pos; i < Count; i++)
                    {
                        box[i] = box[i + 1];
                    }
                }
                Count += type;
            }
        }

        public void Push(int value) //вставл в начало стека
        {
            if (Count == 0)
            {
                box[0] = value;
                Count++;
            }
            else
            {
                moveAllAfter(0, 1);
                box[0] = value;
            }
        }

        public int Pop()//удаление сначала ст
        {
            int re = box[0];
            moveAllAfter(0, -1);
            return re;
        }

        public override string ToString()
        {
            return "Count: " + Count.ToString();
        }

        public override int GetHashCode()
        {
            int hash = 133 + GetHashCode();
            hash = (hash * 15) + Count.GetHashCode();
            return hash;
        }
        public virtual Boolean Equals(Stack obj) //равенство стеков 
        {
            bool a = false;
            if (obj == null) return false;
            if (GetType() != obj.GetType()) return false;
            if (obj.Count == this.Count)//кол эл в ст
            {
                for (int i = 0; i < this.Count; i++)
                {
                    if (this.box[i] == obj.box[i])
                    {
                        if (i == this.Count - 1)
                            return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            else
            {
                return false;
            }
            return a;
        }

        public static Stack operator +(Stack obj1, Stack obj2)
        {
            foreach (int i in obj2.box)
                obj1.Push(i);
            return obj1;
        }

        public static Stack operator --(Stack obj1)
        {
            obj1.box[obj1.Count - 1] = 0;
            obj1.Count--;
            return obj1;
        }

        public static Stack operator ++(Stack obj)
        {
            Console.WriteLine("Why u use this?");
            return obj;
        }

        public static bool operator true(Stack Obj1)
        {
            if (Obj1.Count > 0)
                return false;
            else
                return true;
        }
        public static bool operator false(Stack Obj1)
        {
            if (Obj1.Count > 0)
                return true;
            else
                return false;
        }
    }

    public static class MathObject
    {
        static public int median(this Stack obj) //сред арифм
        {
            int re = 0;
            for (int i = 0; i < obj.Count; re += obj.box[i], i++) ;
            return re / obj.Count;
        }

        static public bool noT(char c)
        {
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ' || c == ',')
                return true;
            else
                return false;
        }

        static public int countOfS(this string s)//подсчет кол предложений
        {
            int re = 0;
            for (int i = 1; i < s.Length; i++)
            {
                if (!MathObject.noT(s[i]) && MathObject.noT(s[i - 1]))//если текущ символ не явл стрковым и предыд симв явл строковым то это конец предложения
                    re++;
            }
            return re;
        }

        static public int min(this Stack s)
        {
            int re = s.box[0];
            foreach (int i in s.box)
                re = Math.Min(re, i);
            return re;
        }

        static public int max(this Stack s)
        {
            int re = s.box[0];
            foreach (int i in s.box)
                re = Math.Max(re, i);
            return re;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Stack D = new Stack(2);

            D.Push(0);
            D.Push(7);
            D.Push(23);
            D.Push(13);
            D.Push(69);

            System.Console.WriteLine("Макс эл : " + D.max());
            System.Console.WriteLine("Мин эл : " + D.min());
            System.Console.WriteLine("Сред арифм : " + D.median());

            D.Pop();
            D.show();
            Console.Read();
        }
    }
}




Class text : 
public class Text 
{ 
public string Texttl; 
}
TextBox:

public class TextBox : Text 
{ 
public string _color; 
public int _size; 

public override string ToString() 
{ 
return "Color is: " + _color + "\n" + "Size is: " + _size; 
} 

public TextBox() 
{ 

}
Login Window: 

public class LoginWindow 
{ 
public TextBox login; 
public TextBox password; 

public void FillTextBox(string loginString, string passwdString) 
{ 
login._color = loginString; 
password._color = passwdString; 
} 

public bool Check() 
{ 
if (login != password && password._size >= 6 && password._size <= 12) 
{ 
return true; 
} 
else 
{ 
return false; 
} 
} 
}
Конструктор для него
public LoginWindow(string login, string passwd) 
{ 
FillTextBox(login, passwd); 
}

using System; 
using System.Collections.Generic; 

namespace ConsoleApplication 
{ 
internal class Program 
{ 
public static void Main(string[] args) 
{ 
LoginWindow lw1 = new LoginWindow("lalashkin", "2123123"); 
LoginWindow lw2 = new LoginWindow("catboy", "12314124"); 

User us1 = new User(); 

lw1.Check(); 
lw2.Check(); 
} 
} 
}
User.cs: 

public delegate void UI(); 

public class User 
{ 
public event UI Enter; 

public User() 
{ 

} 

}