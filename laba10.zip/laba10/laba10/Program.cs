﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba10
{
    class SItem
    {
        public string Name;
        public int weight;
        public int sugar;

        public SItem(string a, int b, int c)
        {
            Name = a;
            weight = b;
            sugar = c;
        }
        public override string ToString()
        {
            return Name + " " + weight + " " + sugar;
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arlist = new ArrayList() { 1, 2, 3, 4, 5 };
            Console.WriteLine("Collection:");
            foreach (object o in arlist)
            {
                Console.WriteLine(o);

            }
            arlist.Add("Six");
            arlist.RemoveAt(2);
            Console.WriteLine("\n");
            Console.WriteLine("Collection after changes:");
            foreach (object o in arlist)
            {
                Console.WriteLine(o);

            }
            Console.WriteLine("\n");
            //Search
            int n = arlist.Count;
            Console.WriteLine("Amount of elements: " + n);

            LinkedList<char> linklist = new LinkedList<char>();

            linklist.AddLast('b');
            linklist.AddFirst('a');
            linklist.AddAfter(linklist.Last, 'c');
            linklist.AddBefore(linklist.First, 's');
            LinkedListNode<char> node = linklist.First;
            node = node.Next;
            node = node.Previous;
            foreach (char i in linklist)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("Input value ");
            int s = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < s; i++)
            {
                linklist.RemoveLast();
            }
            foreach (char i in linklist)
            {
                Console.WriteLine(i);
            }
            HashSet<char> hashlist = new HashSet<char>();
            for (node = linklist.First; node != null; node = node.Next)
            {
                hashlist.Add(node.Value);
            }
            Console.WriteLine("HashSet<char>: ");
            foreach (char i in hashlist)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("Input value for search ");
            char c = Convert.ToChar(Console.ReadLine());
            if (hashlist.Contains(c) == true)
            {
                Console.WriteLine("Contains");
            }

            SItem p1 = new SItem("Chokolate sweet", 254, 73);
            SItem p2 = new SItem("Caramel sweet", 123, 58);
            SItem p3 = new SItem("Honey sweet", 200, 54);

            LinkedList<SItem> personlist = new LinkedList<SItem>();

            personlist.AddLast(p1);
            personlist.AddLast(p2);
            personlist.AddLast(p3);

            LinkedListNode<SItem> node1 = personlist.First;
            node1 = node1.Next;
            node1 = node1.Previous;

            foreach (SItem i in personlist)
            {
                Console.WriteLine(i.ToString());
            }

            Console.WriteLine("Input value ");
            int k = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < k; i++)
            {
                personlist.RemoveLast();
            }

            foreach (SItem i in personlist)
            {
                Console.WriteLine(i);
            }
            HashSet<SItem> hashlist1 = new HashSet<SItem>();
            for (node1 = personlist.First; node1 != null; node1 = node1.Next)
            {
                hashlist1.Add(node1.Value);
            }
            Console.WriteLine("HashSet<Person>: ");
            foreach (SItem i in hashlist1)
            {
                Console.WriteLine(i);
            }


            ObservableCollection<SItem> p = new ObservableCollection<SItem>();

            void p_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
            {
                switch (e.Action)
                {
                    case NotifyCollectionChangedAction.Add:
                        SItem newSweet = e.NewItems[0] as SItem;
                        Console.WriteLine("Added new item: " + newSweet.Name);
                        break;
                    case NotifyCollectionChangedAction.Remove:
                        SItem oldSweet = e.OldItems[0] as SItem;
                        Console.WriteLine("Deleted object: " + oldSweet.Name);
                        break;
                }
            }

            p.CollectionChanged += p_CollectionChanged;

            p.Add(p1);
            p.Add(p2);
            p.Add(p1);
            p.Add(p3);
            p.RemoveAt(1);


            foreach (SItem i in p)
            {
                Console.WriteLine(i.ToString());
            }
        }
    }
}

