﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace laba8
{
    public interface iDo<T>
    {
        void Push(T item);
        T Pop();
        void Show();
    }

    public class myException : System.Exception
    {
        public myException() : base() { }
        public myException(string message) : base("[myexc]" + message) { }
    }

    public class stack<T> : iDo<T> where T : struct, IEquatable<T>// T int char etc
    {
        T[] values;
        int count;
        public stack(int c)
        {
            count = c;
            values = new T[count];
            for (int i = 0; i < count; values[i] = default(T), i++) ;
        }

        public void Push(T item)
        {
            try
            {
                if (item.Equals(default(T)))
                    throw new myException("try assign default");
                for (int i = count - 2; i >= 0; i--)
                {
                    values[i + 1] = values[i];
                }
                values[0] = item;
            }
            catch (myException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("something cute");
            }
        }

        public T Pop()
        {
            for (int i = 0; i < count - 1; i++)
            {
                values[i] = values[i + 1];
            }
            values[count - 1] = default(T);
            return values[0];
        }

        public void Show()
        {
            for (int i = 0; i < count; i++)
            {
                if (!values[i].Equals(default(T)))
                    Console.Write(values[i] + " ");
            }
            Console.WriteLine();
        }
    }

    class MainClass
    {
        public static void Main(string[] args)
        {
            stack<int> s = new stack<int>(10);
            s.Push(5);
            s.Push(3);
            s.Push(1);
            s.Push(-8785);
            s.Push(0);
            s.Show();
            s.Pop();
            s.Show();
            stack<long> ss = new stack<long>(5);
        }

    }

}