﻿using System;
using System.IO;
using System.IO.Compression;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba13
{
    //статических и экземплярных методов
    class Program
    {
        class TDADiskInfo
        {
            public void DiskInfo() //c методами для вывода информации о
            {
                DriveInfo[] drives = DriveInfo.GetDrives();
                foreach (DriveInfo drive in drives)
                {
                    Console.WriteLine("----------------Название: {0}", drive.Name);
                    Console.WriteLine("----------------Тип: {0}", drive.DriveType);
                    if (drive.IsReady)
                    {
                        Console.WriteLine("----------------Объем диска: {0}", drive.TotalSize);
                        Console.WriteLine("----------------Свободное пространство: {0}", drive.TotalFreeSpace);
                    }
                    Console.WriteLine();
                }

            }
        }
        class TDALog
        {
            public void WriteInFile()
            {
                var writer = new StreamWriter("tdalogfile.txt");

            }
        }
        class TDADirInfo //c методами для вывода информации о конкретном директории
        {
            static int countFiles = 0;
            static int countSubDir = 0;
            public void DirInfo(string dirName)
            {
                if (Directory.Exists(dirName))
                {
                    Console.WriteLine("Подкаталоги");
                    string[] dirs = Directory.GetDirectories(dirName);
                    foreach (string s in dirs)
                    {
                        countSubDir++;
                        Console.WriteLine(s);
                    }
                    Console.WriteLine("Количество поддиректорий :" + countSubDir);
                    Console.WriteLine();
                    Console.WriteLine("Файлы");
                    string[] files = Directory.GetFiles(dirName);
                    foreach (string s in files)
                    {
                        countFiles++;
                        Console.WriteLine(s);
                    }
                    Console.WriteLine("Количество файлов :" + countFiles);
                }
            }
            public void Info(string dirName)
            {
                DirectoryInfo dirInfo = new DirectoryInfo(dirName);
                Console.WriteLine("Название каталога: {0}", dirInfo.Name);
                Console.WriteLine("Полное название каталога: {0}", dirInfo.FullName);
                Console.WriteLine("Время создания каталога: {0}", dirInfo.CreationTime);
                Console.WriteLine("Корневой каталог: {0}", dirInfo.Root);
                Console.WriteLine("Родительский каталог: {0}", dirInfo.Parent);
            }
        }
        class TDAFileInfo //c методами для вывода информации о конкретном файле
        {
            public void FileData(string path)
            {
                FileInfo fileInf = new FileInfo(path);
                if (fileInf.Exists)
                {
                    Console.WriteLine("Имя файла: {0}", fileInf.Name);
                    Console.WriteLine("Расширение: {0}", fileInf.Extension);
                    Console.WriteLine("Время создания: {0}", fileInf.CreationTime);
                    Console.WriteLine("Размер: {0}", fileInf.Length);
                    Console.WriteLine("Полный путь : {0}", fileInf.DirectoryName);
                }
            }
        }
        class TDAFileManager
        {
            public void TDA(string path, string filePath, string newFilePath)
            {
                DirectoryInfo dirInfo = new DirectoryInfo(path);
                FileInfo fileInfo = new FileInfo(path + "\\" + filePath);

                if (!dirInfo.Exists)
                {
                    dirInfo.Create();
                    fileInfo.Create();
                }

                using (FileStream fstream = new FileStream(path + "\\" + filePath, FileMode.Create))
                {
                    if (Directory.Exists("D:\\"))
                    {
                        string[] dirs = Directory.GetDirectories("D:\\");
                        foreach (string s in dirs)
                        {
                            byte[] array = Encoding.Default.GetBytes(s);
                            fstream.Write(array, 0, array.Length);

                        }
                        string[] files = Directory.GetFiles("D:\\");
                        foreach (string s in files)
                        {
                            byte[] array = Encoding.Default.GetBytes(s);
                            fstream.Write(array, 0, array.Length);
                        }
                        Console.WriteLine("Зайдите в папку:TDA");

                    }

                }

                Console.ReadKey();

                fileInfo.CopyTo(path + "\\" + newFilePath, true);
                fileInfo.Delete();
                //Создать еще один директорий XXXFiles.Скопировать в
                //него все файлы с заданным расширением из заданногопользователем директория.
                DirectoryInfo dInfo = new DirectoryInfo("D:\\TDAFiles");
                dInfo.Create();

                string[] files2 = Directory.GetFiles("D:\\");

                foreach (string s in files2)
                {

                    File.Copy(s, "D:\\TDAFiles\\" + new FileInfo(s).Name);

                }
                foreach (FileInfo Info in dInfo.GetFiles())
                {
                    Info.CopyTo(path + "\\" + Info.Name, true);
                }

            }
        }

        static void Main(string[] args)
        {
            TDADiskInfo diskInfo = new TDADiskInfo();
            TDADirInfo dirInfo = new TDADirInfo();
            TDAFileInfo file = new TDAFileInfo();
            TDAFileManager fileManager = new TDAFileManager();
            diskInfo.DiskInfo();
            fileManager.TDA("D:\\TDA", "tdadirInfo.txt", "NEWFile.txt");
            Console.ReadKey();
            Console.WriteLine("Папки TDA,TDAFiles будут удалены");
            Console.ReadKey();
            Directory.Delete("D:\\TDA", true);
            Directory.Delete("D:\\TDAFiles", true);
        }

    }
}

